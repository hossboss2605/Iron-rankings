
  # Fitness Progress Tracker

  This is a code bundle for Fitness Progress Tracker. The original project is available at https://www.figma.com/design/41IRHbnujfGe1lJXVtqJ84/Fitness-Progress-Tracker.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  