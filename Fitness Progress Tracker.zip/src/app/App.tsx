import { useState } from 'react';
import { MuscleRankList } from './components/MuscleRankList';
import { WeightTracker } from './components/WeightTracker';
import { CalorieCounter } from './components/CalorieCounter';
import { MuscleMap } from './components/MuscleMap';
import { ExerciseGuide } from './components/ExerciseGuide';
import { Dumbbell, Menu, X, Trophy, User, Scale, Utensils, BookOpen } from 'lucide-react';
import { Toaster } from './components/ui/sonner';

type Section = 'rankings' | 'map' | 'weight' | 'calories' | 'exercises';

export default function App() {
  const [currentSection, setCurrentSection] = useState<Section>('rankings');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const menuItems = [
    { id: 'rankings' as Section, label: 'Rankings', icon: Trophy },
    { id: 'map' as Section, label: 'Muscle Map', icon: User },
    { id: 'weight' as Section, label: 'Weight', icon: Scale },
    { id: 'calories' as Section, label: 'Calories', icon: Utensils },
    { id: 'exercises' as Section, label: 'Exercise Guide', icon: BookOpen },
  ];

  const handleMenuClick = (section: Section) => {
    setCurrentSection(section);
    setSidebarOpen(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-orange-950 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 text-center relative">
          {/* Hamburger Menu Button */}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="absolute right-0 top-0 p-2 text-orange-500 hover:text-orange-400 transition-colors z-50"
            aria-label="Toggle menu"
          >
            {sidebarOpen ? <X className="w-8 h-8" /> : <Menu className="w-8 h-8" />}
          </button>

          <div className="flex items-center justify-center gap-3 mb-2">
            <Dumbbell className="w-10 h-10 text-orange-500 animate-pulse" />
            <h1 className="text-4xl text-white bg-gradient-to-r from-orange-400 to-orange-600 bg-clip-text text-transparent font-bold">
              Iron Rankings
            </h1>
          </div>
          <p className="text-gray-300">
            Track your strength journey from Bronze to Absolute Legend
          </p>

          {/* Motivational Banner - Only show on Rankings page */}
          {currentSection === 'rankings' && (
            <div className="mt-6 relative overflow-hidden rounded-xl border-2 border-orange-600/30 shadow-2xl">
              <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/80 z-10" />
              <img 
                src="https://images.unsplash.com/photo-1669989179336-b2234d2878df?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXRuZXNzJTIwbW90aXZhdGlvbiUyMGd5bXxlbnwxfHx8fDE3NjczMDA4MTh8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Gym motivation"
                className="w-full h-32 object-cover opacity-40"
              />
              <div className="absolute inset-0 z-20 flex flex-col items-center justify-center text-center p-4">
                <Trophy className="w-8 h-8 text-orange-500 mb-2" />
                <p className="text-xl md:text-2xl font-bold text-white mb-1">
                  "The iron never lies"
                </p>
                <p className="text-sm text-orange-400">
                  Every rep brings you closer to legend status
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Sidebar Overlay */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-40"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Sidebar */}
        <div
          className={`fixed top-0 left-0 h-full w-64 bg-gray-900 border-r-2 border-orange-600 transform transition-transform duration-300 ease-in-out z-50 ${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full'
          }`}
        >
          <div className="p-6">
            <div className="flex items-center gap-2 mb-8 mt-2">
              <Dumbbell className="w-6 h-6 text-orange-500" />
              <h2 className="text-xl text-orange-400 font-bold">Menu</h2>
            </div>

            <nav className="space-y-2">
              {menuItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleMenuClick(item.id)}
                    className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all ${
                      currentSection === item.id
                        ? 'bg-orange-600 text-white'
                        : 'text-gray-300 hover:bg-gray-800 hover:text-orange-400'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Main Content */}
        <div className="w-full">
          {currentSection === 'rankings' && <MuscleRankList />}
          {currentSection === 'map' && <MuscleMap />}
          {currentSection === 'weight' && (
            <div className="max-w-2xl mx-auto">
              <WeightTracker />
            </div>
          )}
          {currentSection === 'calories' && (
            <div className="max-w-2xl mx-auto">
              <CalorieCounter />
            </div>
          )}
          {currentSection === 'exercises' && (
            <div className="max-w-2xl mx-auto">
              <ExerciseGuide />
            </div>
          )}
        </div>
      </div>
      
      <Toaster />
    </div>
  );
}