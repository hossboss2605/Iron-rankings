import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Apple, Plus, Trash2, Camera, Target, TrendingUp, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

interface CalorieEntry {
  id: string;
  date: string;
  food: string;
  calories: number;
}

export function CalorieCounter() {
  const [entries, setEntries] = useState<CalorieEntry[]>(() => {
    const saved = localStorage.getItem('calorieEntries');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [foodName, setFoodName] = useState('');
  const [calories, setCalories] = useState('');
  const [dailyGoal, setDailyGoal] = useState(() => {
    const saved = localStorage.getItem('dailyCalorieGoal');
    return saved ? parseInt(saved) : 2000;
  });
  const [dailyGoalInput, setDailyGoalInput] = useState(() => {
    const saved = localStorage.getItem('dailyCalorieGoal');
    return saved ? saved : '2000';
  });
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    localStorage.setItem('calorieEntries', JSON.stringify(entries));
  }, [entries]);

  useEffect(() => {
    localStorage.setItem('dailyCalorieGoal', dailyGoal.toString());
  }, [dailyGoal]);

  const addEntry = () => {
    if (!foodName || !calories || parseFloat(calories) <= 0) {
      toast.error('Please enter food name and calories');
      return;
    }
    
    const entry: CalorieEntry = {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString(),
      food: foodName,
      calories: parseFloat(calories)
    };
    
    setEntries(prev => [...prev, entry]);
    setFoodName('');
    setCalories('');
    toast.success('Calorie entry added!');
  };

  const deleteEntry = (id: string) => {
    setEntries(prev => prev.filter(e => e.id !== id));
  };

  const handleCameraCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Placeholder for camera/image processing
      toast.info('Camera feature coming soon! This would use AI to analyze food and estimate calories. For now, please enter calories manually.');
      // In a real app, you would upload this image to a food recognition API
      // like Clarifai, Google Cloud Vision, or a specialized food API
    }
  };

  const todayEntries = entries.filter(e => e.date === new Date().toLocaleDateString());
  const todayTotal = todayEntries.reduce((sum, e) => sum + e.calories, 0);
  const remainingCalories = dailyGoal - todayTotal;

  return (
    <Card className="bg-gray-900 border-orange-900 text-white">
      <CardHeader className="border-b border-orange-900">
        <CardTitle className="flex items-center gap-2 text-orange-400">
          <Apple className="w-5 h-5" />
          Calorie Tracker
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Daily Goal */}
        <div>
          <Label htmlFor="daily-goal" className="text-gray-200">Daily Calorie Goal</Label>
          <Input
            id="daily-goal"
            type="number"
            value={dailyGoalInput}
            onChange={(e) => {
              setDailyGoalInput(e.target.value);
              const parsed = parseInt(e.target.value);
              if (!isNaN(parsed) && parsed > 0) {
                setDailyGoal(parsed);
              }
            }}
            onBlur={() => {
              // Reset to current dailyGoal if empty or invalid
              if (dailyGoalInput === '' || isNaN(parseInt(dailyGoalInput))) {
                setDailyGoalInput(dailyGoal.toString());
              }
            }}
            className="w-32 bg-gray-700 border-gray-600 text-white"
          />
        </div>

        {/* Today's Progress */}
        <div className="p-4 bg-gradient-to-r from-orange-900/30 to-orange-800/30 border border-orange-700 rounded-lg">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-sm text-gray-300">Consumed</div>
              <div className="text-xl font-bold text-orange-400">{todayTotal}</div>
            </div>
            <div>
              <div className="text-sm text-gray-300">Goal</div>
              <div className="text-xl font-bold text-white">{dailyGoal}</div>
            </div>
            <div>
              <div className="text-sm text-gray-300">Remaining</div>
              <div className={`text-xl font-bold ${remainingCalories < 0 ? 'text-red-400' : 'text-green-400'}`}>
                {remainingCalories}
              </div>
            </div>
          </div>
          {/* Progress Bar */}
          <div className="mt-3 h-2 bg-gray-700 rounded-full overflow-hidden">
            <div 
              className="h-full bg-orange-600 transition-all"
              style={{ width: `${Math.min((todayTotal / dailyGoal) * 100, 100)}%` }}
            />
          </div>
        </div>

        {/* Add Entry */}
        <div className="space-y-3">
          <h4 className="font-medium text-gray-200">Add Food</h4>
          
          {/* Camera Button */}
          <div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleCameraCapture}
              className="hidden"
            />
            <Button
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              className="w-full bg-gray-800 border-gray-600 text-gray-200 hover:bg-gray-700"
            >
              <Camera className="w-4 h-4 mr-2" />
              Take Photo to Estimate Calories
            </Button>
            <p className="text-xs text-gray-400 mt-1">
              Or enter manually below
            </p>
          </div>

          <div>
            <Label htmlFor="food-name" className="text-gray-200">Food Name</Label>
            <Input
              id="food-name"
              value={foodName}
              onChange={(e) => setFoodName(e.target.value)}
              placeholder="e.g., Chicken Breast"
              className="bg-gray-700 border-gray-600 text-white"
            />
          </div>

          <div>
            <Label htmlFor="calories" className="text-gray-200">Calories</Label>
            <Input
              id="calories"
              type="number"
              value={calories}
              onChange={(e) => setCalories(e.target.value)}
              placeholder="e.g., 250"
              className="bg-gray-700 border-gray-600 text-white"
            />
          </div>

          <Button onClick={addEntry} className="w-full bg-orange-600 hover:bg-orange-700">
            <Plus className="w-4 h-4 mr-1" />
            Add Entry
          </Button>
        </div>

        {/* Today's Entries */}
        {todayEntries.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-medium text-gray-200">Today's Meals</h4>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {todayEntries.map(entry => (
                <div key={entry.id} className="flex items-center justify-between p-3 bg-gray-800 border border-gray-700 rounded-lg">
                  <div className="flex-1">
                    <div className="font-medium text-white">{entry.food}</div>
                    <div className="text-sm text-gray-400">{entry.calories} cal</div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteEntry(entry.id)}
                    className="hover:bg-gray-700"
                  >
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}