import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dumbbell, ChevronDown, ChevronUp, Info } from 'lucide-react';
import { MUSCLE_GROUPS } from '../utils/ranks';

interface Exercise {
  name: string;
  description: string;
  tips: string[];
}

interface MuscleGroupExercises {
  group: string;
  exercises: Exercise[];
}

const EXERCISE_DATA: MuscleGroupExercises[] = [
  {
    group: 'Chest',
    exercises: [
      {
        name: 'Barbell Bench Press',
        description: 'The king of chest exercises. Lie on a bench and press the barbell up from chest level.',
        tips: ['Keep feet flat on floor', 'Retract shoulder blades', 'Lower bar to mid-chest', 'Drive through legs'],
      },
      {
        name: 'Dumbbell Flyes',
        description: 'Isolation exercise that stretches and contracts the chest. Use controlled movements.',
        tips: ['Slight bend in elbows', 'Arc motion like hugging a tree', 'Feel the stretch at bottom'],
      },
      {
        name: 'Push-Ups',
        description: 'Bodyweight classic that builds chest, shoulders, and triceps.',
        tips: ['Keep core tight', 'Full range of motion', 'Elbows at 45 degrees'],
      }
    ]
  },
  {
    group: 'Back',
    exercises: [
      {
        name: 'Pull-Ups',
        description: 'Ultimate back builder. Pull yourself up until chin clears the bar.',
        tips: ['Full dead hang at bottom', 'Pull elbows down and back', 'Engage lats', 'Control the descent'],
      },
      {
        name: 'Barbell Rows',
        description: 'Compound movement for back thickness. Pull barbell to lower chest/upper abs.',
        tips: ['Hinge at hips', 'Keep back flat', 'Pull to belly button', 'Squeeze shoulder blades'],
      },
      {
        name: 'Deadlifts',
        description: 'Full body compound lift that heavily targets the posterior chain.',
        tips: ['Start with bar over mid-foot', 'Keep spine neutral', 'Drive through heels', 'Lock out at top'],
      }
    ]
  },
  {
    group: 'Shoulders',
    exercises: [
      {
        name: 'Overhead Press',
        description: 'Press weight overhead from shoulder level. Builds all three deltoid heads.',
        tips: ['Grip slightly wider than shoulders', 'Brace core', 'Press straight up', 'Lock out overhead'],
      },
      {
        name: 'Lateral Raises',
        description: 'Isolation for side delts. Raise dumbbells out to sides until parallel with ground.',
        tips: ['Slight bend in elbows', 'Lead with elbows', 'Control the weight', 'Avoid swinging'],
      },
      {
        name: 'Face Pulls',
        description: 'Target rear delts and upper back. Pull rope to face level.',
        tips: ['High cable position', 'Pull to nose/forehead', 'Squeeze rear delts', 'Elbows high'],
      }
    ]
  },
  {
    group: 'Biceps',
    exercises: [
      {
        name: 'Barbell Curls',
        description: 'Classic mass builder for biceps. Curl bar from thighs to shoulders.',
        tips: ['Keep elbows tucked', 'No swinging', 'Squeeze at top', 'Control the negative'],
      },
      {
        name: 'Hammer Curls',
        description: 'Neutral grip curls that target biceps and forearms.',
        tips: ['Thumbs up position', 'Keep wrists neutral', 'No rotation', 'Controlled tempo'],
      }
    ]
  },
  {
    group: 'Triceps',
    exercises: [
      {
        name: 'Close-Grip Bench Press',
        description: 'Compound exercise emphasizing triceps. Use narrower grip than regular bench.',
        tips: ['Hands shoulder-width', 'Elbows tucked in', 'Touch lower chest', 'Full lockout'],
      },
      {
        name: 'Tricep Dips',
        description: 'Bodyweight exercise for tricep mass. Lower body between parallel bars.',
        tips: ['Lean slightly forward', 'Full stretch at bottom', 'Lock out at top', 'Keep core tight'],
      },
      {
        name: 'Overhead Extensions',
        description: 'Isolation for long head of triceps. Extend weight overhead.',
        tips: ['Keep elbows close to head', 'Full stretch', 'Control the weight', 'No elbow flare'],
      }
    ]
  },
  {
    group: 'Abs',
    exercises: [
      {
        name: 'Planks',
        description: 'Isometric core strengthener. Hold push-up position on forearms.',
        tips: ['Keep body straight', 'Squeeze glutes', 'Breathe normally', 'No sagging hips'],
      },
      {
        name: 'Hanging Leg Raises',
        description: 'Advanced ab exercise. Hang from bar and raise legs to 90 degrees.',
        tips: ['Control the swing', 'Raise legs slowly', 'Tilt pelvis up', 'Lower with control'],
      },
      {
        name: 'Cable Crunches',
        description: 'Weighted ab exercise using cable machine. Crunch downward with rope.',
        tips: ['Kneel facing cable', 'Hold rope behind head', 'Crunch down', 'Squeeze abs'],
      }
    ]
  },
  {
    group: 'Quadriceps',
    exercises: [
      {
        name: 'Barbell Squats',
        description: 'The king of leg exercises. Lower into squat position with bar on back.',
        tips: ['Bar on upper traps', 'Depth below parallel', 'Knees track over toes', 'Drive through heels'],
      },
      {
        name: 'Leg Press',
        description: 'Machine-based quad builder. Press weight up at angle.',
        tips: ['Full range of motion', 'Keep back flat', 'Controlled descent', 'No lockout bounce'],
      },
      {
        name: 'Lunges',
        description: 'Unilateral leg exercise. Step forward and lower back knee to ground.',
        tips: ['90-90 knee angles', 'Keep torso upright', 'Drive through front heel', 'Alternate legs'],
      }
    ]
  },
  {
    group: 'Hamstrings',
    exercises: [
      {
        name: 'Romanian Deadlifts',
        description: 'Hip hinge movement targeting hamstrings. Lower bar to mid-shin.',
        tips: ['Slight knee bend', 'Push hips back', 'Feel stretch in hamstrings', 'Keep bar close'],
      },
      {
        name: 'Leg Curls',
        description: 'Isolation for hamstrings. Curl weight up while lying prone.',
        tips: ['Full range of motion', 'Squeeze at top', 'Control the eccentric', 'No hip lift'],
      }
    ]
  },
  {
    group: 'Glutes',
    exercises: [
      {
        name: 'Hip Thrusts',
        description: 'Premier glute builder. Thrust hips up with barbell across hips.',
        tips: ['Upper back on bench', 'Drive through heels', 'Squeeze glutes at top', 'Chin tucked'],
      },
      {
        name: 'Bulgarian Split Squats',
        description: 'Single-leg exercise emphasizing glutes and quads.',
        tips: ['Rear foot elevated', 'Front foot far forward', 'Lower straight down', 'Drive through front heel'],
      }
    ]
  },
  {
    group: 'Calves',
    exercises: [
      {
        name: 'Standing Calf Raises',
        description: 'Raise up on toes while standing. Targets gastrocnemius.',
        tips: ['Full range of motion', 'Pause at top', 'Deep stretch at bottom', 'No bouncing'],
      },
      {
        name: 'Seated Calf Raises',
        description: 'Calf raises performed while seated. Targets soleus.',
        tips: ['Knees at 90 degrees', 'Weight on knees', 'Full stretch', 'Squeeze at top'],
      }
    ]
  },
  {
    group: 'Forearms',
    exercises: [
      {
        name: 'Wrist Curls',
        description: 'Curl wrists upward with dumbbells or barbell.',
        tips: ['Forearms on bench', 'Let weight stretch', 'Curl wrists up', 'Slow and controlled'],
      },
      {
        name: 'Farmer Walks',
        description: 'Carry heavy weights for distance. Great for grip and forearms.',
        tips: ['Heavy weights', 'Walk with control', 'Keep shoulders back', 'Squeeze grip'],
      }
    ]
  },
  {
    group: 'Traps',
    exercises: [
      {
        name: 'Barbell Shrugs',
        description: 'Shrug shoulders straight up with barbell.',
        tips: ['Keep arms straight', 'Shrug straight up', 'Squeeze at top', 'No rolling shoulders'],
      },
      {
        name: 'Farmer Walks',
        description: 'Heavy carries that build traps and grip strength.',
        tips: ['Heavy dumbbells', 'Keep shoulders elevated', 'Walk tall', 'Controlled steps'],
      }
    ]
  }
];

export function ExerciseGuide() {
  const [expandedGroup, setExpandedGroup] = useState<string | null>(null);

  const toggleGroup = (group: string) => {
    setExpandedGroup(expandedGroup === group ? null : group);
  };

  return (
    <Card className="bg-gray-900 border-orange-900 text-white">
      <CardHeader className="border-b border-orange-900">
        <CardTitle className="flex items-center gap-2 text-orange-400">
          <Dumbbell className="w-5 h-5" />
          Exercise Guide
        </CardTitle>
        <p className="text-sm text-gray-400 mt-2">
          Learn proper form and technique for each muscle group
        </p>
      </CardHeader>
      <CardContent className="space-y-3">
        {EXERCISE_DATA.map((muscleGroup) => (
          <div key={muscleGroup.group} className="border border-gray-700 rounded-lg overflow-hidden bg-gray-800">
            {/* Muscle Group Header */}
            <button
              onClick={() => toggleGroup(muscleGroup.group)}
              className="w-full flex items-center justify-between p-4 hover:bg-gray-750 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div 
                  className="w-4 h-4 rounded-full"
                  style={{ 
                    backgroundColor: MUSCLE_GROUPS.find(g => g.name === muscleGroup.group)?.color || '#666'
                  }}
                />
                <span className="font-semibold text-lg text-white">{muscleGroup.group}</span>
                <span className="text-sm text-gray-400">
                  ({muscleGroup.exercises.length} exercises)
                </span>
              </div>
              {expandedGroup === muscleGroup.group ? (
                <ChevronUp className="w-5 h-5 text-orange-400" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-400" />
              )}
            </button>

            {/* Exercises List */}
            {expandedGroup === muscleGroup.group && (
              <div className="border-t border-gray-700 bg-gray-850">
                {muscleGroup.exercises.map((exercise, idx) => (
                  <div
                    key={idx}
                    className="p-4 border-b border-gray-700 last:border-b-0 hover:bg-gray-800 transition-colors cursor-pointer"
                  >
                    <h4 className="font-semibold text-orange-400 mb-2">{exercise.name}</h4>
                    <p className="text-sm text-gray-300 mb-3">{exercise.description}</p>
                    
                    {/* Form Tips */}
                    <div className="space-y-1">
                      <p className="text-xs font-semibold text-gray-400 uppercase">Form Tips:</p>
                      <ul className="space-y-1">
                        {exercise.tips.map((tip, tipIdx) => (
                          <li key={tipIdx} className="text-sm text-gray-400 flex items-start gap-2">
                            <span className="text-orange-500 mt-0.5">•</span>
                            <span>{tip}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}