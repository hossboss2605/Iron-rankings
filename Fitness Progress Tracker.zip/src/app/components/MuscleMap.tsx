import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { User, RotateCcw } from 'lucide-react';
import { MUSCLE_GROUPS, getRankColor, DEFAULT_WEIGHTS, getAverageWeightForGroup, getRankColorForGroup } from '../utils/ranks';
import { Button } from './ui/button';

interface MuscleData {
  [key: string]: number;
}

export function MuscleMap() {
  const [muscleData, setMuscleData] = useState<MuscleData>(() => {
    const saved = localStorage.getItem('muscleData');
    if (saved) {
      const parsed = JSON.parse(saved);
      
      // Migration: Reset abs to difficulty level 0 if they have invalid values
      const absGroup = MUSCLE_GROUPS.find(g => g.name === 'Abs');
      if (absGroup) {
        absGroup.subMuscles.forEach(subMuscle => {
          // If abs have values outside 0-7 range, reset to 0
          if (parsed[subMuscle] === undefined || parsed[subMuscle] > 7 || parsed[subMuscle] < 0) {
            parsed[subMuscle] = 0;
          }
        });
      }
      
      return parsed;
    }
    const initial: MuscleData = {};
    // Initialize with all sub-muscles at their minimum/beginner values
    MUSCLE_GROUPS.forEach(group => {
      group.subMuscles.forEach(subMuscle => {
        initial[subMuscle] = DEFAULT_WEIGHTS[subMuscle];
      });
    });
    return initial;
  });

  useEffect(() => {
    const handleStorageChange = () => {
      const saved = localStorage.getItem('muscleData');
      if (saved) {
        setMuscleData(JSON.parse(saved));
      }
    };

    window.addEventListener('storage', handleStorageChange);
    const interval = setInterval(handleStorageChange, 500);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
    };
  }, []);

  // Get color based on average weight of sub-muscles in a group
  const getColor = (groupName: string) => {
    return getRankColorForGroup(groupName, muscleData);
  };

  return (
    <Card className="bg-gray-900 border-orange-900 text-white">
      <CardHeader className="border-b border-orange-900">
        <CardTitle className="flex items-center gap-2 text-orange-400">
          <User className="w-5 h-5" />
          Anatomical Muscle Map
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center justify-center bg-gradient-to-b from-gray-950 to-black p-6 rounded-lg">
          {/* Front View - Centered */}
          <div className="flex flex-col items-center">
            <svg width="300" height="500" viewBox="0 0 300 500" className="border-2 border-gray-800 rounded-lg bg-black">
              {/* Spiky Hair - Goku Style */}
              <path d="M 150 10 L 140 25 L 150 20 L 160 25 Z" fill="#1a1a1a" stroke="#333" strokeWidth="2"/>
              <path d="M 140 15 L 130 30 L 140 25 L 145 30 Z" fill="#1a1a1a" stroke="#333" strokeWidth="2"/>
              <path d="M 160 15 L 170 30 L 160 25 L 155 30 Z" fill="#1a1a1a" stroke="#333" strokeWidth="2"/>
              <path d="M 150 8 L 145 22 L 150 18 L 155 22 Z" fill="#1a1a1a" stroke="#333" strokeWidth="2"/>
              
              {/* Head */}
              <ellipse cx="150" cy="45" rx="28" ry="32" fill="#1a1a1a" stroke="#333" strokeWidth="2"/>
              
              {/* Neck */}
              <rect x="140" y="70" width="20" height="15" fill="#1a1a1a" stroke="#333" strokeWidth="1"/>
              
              {/* Shoulders - More angular/muscular */}
              <ellipse cx="95" cy="95" rx="32" ry="22" 
                fill={getColor('Shoulders')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              <ellipse cx="205" cy="95" rx="32" ry="22" 
                fill={getColor('Shoulders')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              
              {/* Chest - More defined pecs */}
              <ellipse cx="135" cy="125" rx="28" ry="35" 
                fill={getColor('Chest')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              <ellipse cx="165" cy="125" rx="28" ry="35" 
                fill={getColor('Chest')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              
              {/* Biceps - More prominent */}
              <ellipse cx="75" cy="145" rx="20" ry="32" 
                fill={getColor('Biceps')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              <ellipse cx="225" cy="145" rx="20" ry="32" 
                fill={getColor('Biceps')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              
              {/* Triceps (visible from front angle) */}
              <ellipse cx="70" cy="150" rx="12" ry="24" 
                fill={getColor('Triceps')} 
                opacity="0.5"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              <ellipse cx="230" cy="150" rx="12" ry="24" 
                fill={getColor('Triceps')} 
                opacity="0.5"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              
              {/* Abs - Six pack definition */}
              <rect x="125" y="165" width="24" height="22" rx="4" 
                fill={getColor('Abs')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              <rect x="151" y="165" width="24" height="22" rx="4" 
                fill={getColor('Abs')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              <rect x="125" y="190" width="24" height="22" rx="4" 
                fill={getColor('Abs')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              <rect x="151" y="190" width="24" height="22" rx="4" 
                fill={getColor('Abs')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              <rect x="125" y="215" width="24" height="22" rx="4" 
                fill={getColor('Abs')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              <rect x="151" y="215" width="24" height="22" rx="4" 
                fill={getColor('Abs')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              
              {/* Forearms */}
              <rect x="58" y="190" width="26" height="65" rx="13" 
                fill={getColor('Forearms')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              <rect x="216" y="190" width="26" height="65" rx="13" 
                fill={getColor('Forearms')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              
              {/* Quadriceps - More defined */}
              <rect x="110" y="260" width="38" height="125" rx="19" 
                fill={getColor('Quadriceps')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              <rect x="152" y="260" width="38" height="125" rx="19" 
                fill={getColor('Quadriceps')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              
              {/* Calves */}
              <ellipse cx="129" cy="420" rx="22" ry="38" 
                fill={getColor('Calves')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              <ellipse cx="171" cy="420" rx="22" ry="38" 
                fill={getColor('Calves')} 
                opacity="0.8"
                style={{ transition: 'fill 0.5s' }}
                filter="url(#glow)"/>
              
              {/* Glow Filter */}
              <defs>
                <filter id="glow">
                  <feGaussianBlur stdDeviation="5" result="coloredBlur"/>
                  <feMerge>
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>
              </defs>
            </svg>
          </div>
        </div>
        
        {/* Compact Legend - Muscle-Specific Ranges */}
        <div className="mt-3 p-2 bg-gray-800 border border-gray-700 rounded-lg">
          <h4 className="font-medium mb-1 text-center text-orange-400 text-xs">Muscle-Specific Weight Ranges</h4>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-1.5 text-xs">
            {MUSCLE_GROUPS.map((group) => {
              const currentColor = getColor(group.name);
              return (
                <div key={group.name} className="p-1.5 bg-gray-900 border border-gray-600 rounded hover:border-orange-700 transition-colors">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <div 
                      className="w-3 h-3 rounded-full border border-gray-600" 
                      style={{ backgroundColor: currentColor }}
                    />
                    <div className="font-bold text-orange-400 text-xs">{group.name}</div>
                  </div>
                  <div className="text-[10px] text-gray-400 ml-4.5">
                    {group.useDifficulty ? 'Beginner → Extreme' : `${group.range.min}-${group.range.max} lbs`}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        
        {/* Reset Button */}
        <div className="mt-4 text-center">
          <Button
            className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded"
            onClick={() => {
              const initial: MuscleData = {};
              MUSCLE_GROUPS.forEach(group => {
                group.subMuscles.forEach(subMuscle => {
                  initial[subMuscle] = DEFAULT_WEIGHTS[subMuscle];
                });
              });
              setMuscleData(initial);
              localStorage.setItem('muscleData', JSON.stringify(initial));
            }}
          >
            <RotateCcw className="w-4 h-4 mr-1" />
            Reset Muscle Data
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}