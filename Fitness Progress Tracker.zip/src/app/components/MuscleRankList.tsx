import { useState, useEffect } from 'react';
import { MUSCLE_GROUPS, getRankForWeight, DEFAULT_WEIGHTS, usesDifficultyLevel, getRankForDifficulty, ABS_DIFFICULTY_LEVELS, getAverageWeightForGroup } from '../utils/ranks';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Trophy, ChevronDown, ChevronUp, Crown, Medal, Award } from 'lucide-react';

interface MuscleData {
  [key: string]: number;
}

interface InputValues {
  [key: string]: string;
}

interface RankedMuscleGroup {
  name: string;
  score: number; // 0-100 percentage of progress
  rankIndex: number; // 0-7 rank tier
  avgValue: number; // average weight or difficulty
  group: typeof MUSCLE_GROUPS[0];
}

export function MuscleRankList() {
  const [muscleData, setMuscleData] = useState<MuscleData>(() => {
    const saved = localStorage.getItem('muscleData');
    const initial: MuscleData = {};
    
    // Initialize with all sub-muscles using DEFAULT_WEIGHTS
    MUSCLE_GROUPS.forEach(group => {
      group.subMuscles.forEach(subMuscle => {
        if (group.useDifficulty) {
          // For abs, always start at 0 (Beginner)
          initial[subMuscle] = 0;
        } else {
          // For weight-based muscles, use DEFAULT_WEIGHTS or min range
          initial[subMuscle] = DEFAULT_WEIGHTS[subMuscle] || group.range.min;
        }
      });
    });
    
    if (saved) {
      const savedData = JSON.parse(saved);
      // Only merge saved data for weight-based muscles
      MUSCLE_GROUPS.forEach(group => {
        group.subMuscles.forEach(subMuscle => {
          if (!group.useDifficulty && savedData[subMuscle] !== undefined) {
            // For weight-based muscles, use saved value if available
            initial[subMuscle] = savedData[subMuscle];
          }
          // For abs (useDifficulty), always reset to 0 - ignore saved values
        });
      });
      
      // Save the cleaned data back to localStorage
      localStorage.setItem('muscleData', JSON.stringify(initial));
    }
    
    return initial;
  });

  // Separate state for input display values
  const [inputValues, setInputValues] = useState<InputValues>(() => {
    const saved = localStorage.getItem('muscleData');
    if (saved) {
      const data = JSON.parse(saved);
      const values: InputValues = {};
      MUSCLE_GROUPS.forEach(group => {
        group.subMuscles.forEach(subMuscle => {
          values[subMuscle] = (data[subMuscle] || DEFAULT_WEIGHTS[subMuscle] || 50).toString();
        });
      });
      return values;
    }
    const initial: InputValues = {};
    MUSCLE_GROUPS.forEach(group => {
      group.subMuscles.forEach(subMuscle => {
        initial[subMuscle] = (DEFAULT_WEIGHTS[subMuscle] || 50).toString();
      });
    });
    return initial;
  });

  // Track which muscle groups are expanded
  const [expandedGroups, setExpandedGroups] = useState<{ [key: string]: boolean }>({});

  // Save function
  const saveToLocalStorage = () => {
    localStorage.setItem('muscleData', JSON.stringify(muscleData));
  };

  const toggleGroup = (groupName: string) => {
    setExpandedGroups(prev => ({
      ...prev,
      [groupName]: !prev[groupName]
    }));
  };

  const handleWeightChange = (muscle: string, value: string) => {
    // Update input display value immediately
    setInputValues(prev => ({
      ...prev,
      [muscle]: value
    }));
  };

  const handleBlur = (muscle: string) => {
    // On blur, if empty or invalid, reset to last valid value from saved data
    const currentValue = inputValues[muscle];
    if (currentValue === '' || isNaN(parseFloat(currentValue))) {
      setInputValues(prev => ({
        ...prev,
        [muscle]: (muscleData[muscle] || 50).toString()
      }));
    }
  };

  const handleSave = (muscle: string) => {
    const value = inputValues[muscle];
    const weight = parseFloat(value);
    if (!isNaN(weight) && weight >= 0) {
      const newData = {
        ...muscleData,
        [muscle]: weight
      };
      setMuscleData(newData);
      localStorage.setItem('muscleData', JSON.stringify(newData));
    }
  };

  // Calculate rankings for all muscle groups
  const calculateRankings = (): RankedMuscleGroup[] => {
    return MUSCLE_GROUPS.map(group => {
      if (group.useDifficulty) {
        // For abs: average difficulty level (0-7)
        const difficultyValues = group.subMuscles.map(subMuscle => muscleData[subMuscle] || 0);
        const avgDifficulty = difficultyValues.reduce((acc, val) => acc + val, 0) / difficultyValues.length;
        const score = (avgDifficulty / 7) * 100;
        const rankIndex = Math.min(Math.floor(avgDifficulty), 7);
        
        return {
          name: group.name,
          score,
          rankIndex,
          avgValue: avgDifficulty,
          group
        };
      } else {
        // For weight-based: calculate percentage of range
        const weights = group.subMuscles.map(subMuscle => muscleData[subMuscle] || group.range.min);
        const avgWeight = weights.reduce((acc, w) => acc + w, 0) / weights.length;
        const range = group.range.max - group.range.min;
        const progress = avgWeight - group.range.min;
        const score = Math.min(Math.max((progress / range) * 100, 0), 100);
        const rankIndex = Math.min(Math.floor((score / 100) * 7.999), 7); // Ensures max is 7
        
        return {
          name: group.name,
          score,
          rankIndex,
          avgValue: avgWeight,
          group
        };
      }
    }).sort((a, b) => b.score - a.score); // Sort highest to lowest
  };

  const rankedGroups = calculateRankings();
  const topThree = rankedGroups.slice(0, 3);
  const restOfGroups = rankedGroups.slice(3);

  const RANK_NAMES = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Grandmaster', 'Absolute Legend'];
  const RANK_COLORS = [
    { color: '#CD7F32', bgColor: '#FFF8F0' },  // Bronze
    { color: '#C0C0C0', bgColor: '#F5F5F5' },  // Silver
    { color: '#FFD700', bgColor: '#FFFACD' },  // Gold
    { color: '#E5E4E2', bgColor: '#F0F0F0' },  // Platinum
    { color: '#B9F2FF', bgColor: '#E0F7FF' },  // Diamond
    { color: '#9B59B6', bgColor: '#F4ECF7' },  // Master
    { color: '#E74C3C', bgColor: '#FADBD8' },  // Grandmaster
    { color: '#FF0000', bgColor: '#FFE6E6' }   // Absolute Legend
  ];

  const getPodiumHeight = (position: number) => {
    if (position === 0) return 'h-32'; // 1st place - tallest (reduced from h-48)
    if (position === 1) return 'h-28'; // 2nd place (reduced from h-40)
    return 'h-24'; // 3rd place (reduced from h-32)
  };

  const getPodiumIcon = (position: number) => {
    if (position === 0) return <Crown className="w-6 h-6 text-yellow-400" />; // reduced from w-8 h-8
    if (position === 1) return <Medal className="w-5 h-5 text-gray-400" />; // reduced from w-7 h-7
    return <Award className="w-5 h-5 text-orange-600" />; // reduced from w-6 h-6
  };

  const getPodiumColor = (position: number) => {
    if (position === 0) return 'from-yellow-600 to-yellow-800 border-yellow-500'; // Gold
    if (position === 1) return 'from-gray-500 to-gray-700 border-gray-400'; // Silver
    return 'from-orange-700 to-orange-900 border-orange-600'; // Bronze
  };

  return (
    <Card className="bg-gray-900 border-orange-900 text-white">
      <CardHeader className="border-b border-orange-900">
        <CardTitle className="flex items-center gap-2 text-orange-400">
          <Trophy className="w-5 h-5" />
          Muscle Group Rankings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4 pt-4">
        {/* Podium - Top 3 */}
        <div className="relative">
          {/* MVP Banner for #1 */}
          <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 z-10">
            <div className="bg-gradient-to-r from-yellow-500 via-yellow-400 to-yellow-500 px-4 py-1 rounded-full shadow-lg border-2 border-yellow-300 flex items-center gap-2">
              <Crown className="w-4 h-4 text-black" />
              <span className="font-bold text-black text-xs">MVP MUSCLE</span>
            </div>
          </div>

          <div className="flex items-end justify-center gap-3 mt-6">
            {/* 2nd Place - Left */}
            {topThree[1] && (
              <div className="flex flex-col items-center w-24">
                <div className="mb-1 flex flex-col items-center">
                  <Medal className="w-6 h-6 text-gray-400 mb-0.5" />
                  <span className="text-lg font-bold text-gray-400">#2</span>
                </div>
                <button
                  onClick={() => toggleGroup(topThree[1].name)}
                  className={`w-full ${getPodiumHeight(1)} bg-gradient-to-b ${getPodiumColor(1)} border-2 rounded-t-lg flex flex-col items-center justify-center p-2 hover:opacity-90 transition-all cursor-pointer shadow-xl`}
                >
                  <div className="text-center">
                    <div className="font-bold text-white text-xs mb-1">{topThree[1].name}</div>
                    <Badge 
                      style={{ 
                        backgroundColor: RANK_COLORS[topThree[1].rankIndex].bgColor,
                        color: RANK_COLORS[topThree[1].rankIndex].color,
                        borderColor: RANK_COLORS[topThree[1].rankIndex].color
                      }}
                      className="border text-[10px] px-1 py-0"
                    >
                      {RANK_NAMES[topThree[1].rankIndex]}
                    </Badge>
                    <div className="text-[10px] text-gray-200 mt-1">
                      {topThree[1].group.useDifficulty 
                        ? ABS_DIFFICULTY_LEVELS[Math.floor(topThree[1].avgValue)]
                        : `${Math.round(topThree[1].avgValue)} lbs`
                      }
                    </div>
                  </div>
                </button>
              </div>
            )}

            {/* 1st Place - Center (Tallest) */}
            {topThree[0] && (
              <div className="flex flex-col items-center w-28">
                <div className="mb-1 flex flex-col items-center">
                  <Crown className="w-7 h-7 text-yellow-400 mb-0.5" />
                  <span className="text-xl font-bold text-yellow-400">#1</span>
                </div>
                <button
                  onClick={() => toggleGroup(topThree[0].name)}
                  className={`w-full ${getPodiumHeight(0)} bg-gradient-to-b ${getPodiumColor(0)} border-2 rounded-t-lg flex flex-col items-center justify-center p-2 hover:opacity-90 transition-all cursor-pointer shadow-2xl`}
                >
                  <div className="text-center">
                    <div className="font-bold text-white text-sm mb-1">{topThree[0].name}</div>
                    <Badge 
                      style={{ 
                        backgroundColor: RANK_COLORS[topThree[0].rankIndex].bgColor,
                        color: RANK_COLORS[topThree[0].rankIndex].color,
                        borderColor: RANK_COLORS[topThree[0].rankIndex].color
                      }}
                      className="border text-xs px-1.5 py-0.5"
                    >
                      {RANK_NAMES[topThree[0].rankIndex]}
                    </Badge>
                    <div className="text-xs text-gray-200 mt-1">
                      {topThree[0].group.useDifficulty 
                        ? ABS_DIFFICULTY_LEVELS[Math.floor(topThree[0].avgValue)]
                        : `${Math.round(topThree[0].avgValue)} lbs`
                      }
                    </div>
                  </div>
                </button>
              </div>
            )}

            {/* 3rd Place - Right */}
            {topThree[2] && (
              <div className="flex flex-col items-center w-24">
                <div className="mb-1 flex flex-col items-center">
                  <Award className="w-6 h-6 text-orange-600 mb-0.5" />
                  <span className="text-lg font-bold text-orange-600">#3</span>
                </div>
                <button
                  onClick={() => toggleGroup(topThree[2].name)}
                  className={`w-full ${getPodiumHeight(2)} bg-gradient-to-b ${getPodiumColor(2)} border-2 rounded-t-lg flex flex-col items-center justify-center p-2 hover:opacity-90 transition-all cursor-pointer shadow-xl`}
                >
                  <div className="text-center">
                    <div className="font-bold text-white text-xs mb-1">{topThree[2].name}</div>
                    <Badge 
                      style={{ 
                        backgroundColor: RANK_COLORS[topThree[2].rankIndex].bgColor,
                        color: RANK_COLORS[topThree[2].rankIndex].color,
                        borderColor: RANK_COLORS[topThree[2].rankIndex].color
                      }}
                      className="border text-[10px] px-1 py-0"
                    >
                      {RANK_NAMES[topThree[2].rankIndex]}
                    </Badge>
                    <div className="text-[10px] text-gray-200 mt-1">
                      {topThree[2].group.useDifficulty 
                        ? ABS_DIFFICULTY_LEVELS[Math.floor(topThree[2].avgValue)]
                        : `${Math.round(topThree[2].avgValue)} lbs`
                      }
                    </div>
                  </div>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Expanded Details for Top 3 */}
        {topThree.map((rankedGroup) => {
          const isExpanded = expandedGroups[rankedGroup.name];
          if (!isExpanded) return null;
          
          return (
            <div key={`expanded-${rankedGroup.name}`} className="rounded-lg border-2 border-orange-500 bg-gray-800/70 p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-bold text-orange-400">{rankedGroup.name} Sub-Muscles</h3>
                <button 
                  onClick={() => toggleGroup(rankedGroup.name)}
                  className="text-orange-400 hover:text-orange-300"
                >
                  <ChevronUp className="w-5 h-5" />
                </button>
              </div>
              <div className="space-y-3">
                {rankedGroup.group.subMuscles.map(subMuscle => {
                  const value = muscleData[subMuscle] || 0;
                  const isAbs = usesDifficultyLevel(subMuscle);
                  const rank = isAbs 
                    ? getRankForDifficulty(value) 
                    : getRankForWeight(value, subMuscle);
                  
                  return (
                    <div key={subMuscle} className="flex flex-col gap-2 p-3 rounded-md border border-gray-600 bg-gray-800/70">
                      <div className="flex items-center justify-between">
                        <Label htmlFor={`muscle-${subMuscle}`} className="text-gray-200">
                          {subMuscle}
                        </Label>
                        <Badge 
                          style={{ 
                            backgroundColor: rank.bgColor,
                            color: rank.color,
                            borderColor: rank.color
                          }}
                          className="border-2 px-2 py-0.5 text-xs"
                        >
                          {rank.name}
                        </Badge>
                      </div>
                      
                      {isAbs ? (
                        <div className="flex items-center gap-2">
                          <select
                            id={`muscle-${subMuscle}`}
                            value={value}
                            onChange={(e) => {
                              const difficultyIndex = parseInt(e.target.value);
                              setMuscleData(prev => ({
                                ...prev,
                                [subMuscle]: difficultyIndex
                              }));
                              // Auto-save for difficulty changes
                              setTimeout(() => {
                                const newData = { ...muscleData, [subMuscle]: difficultyIndex };
                                localStorage.setItem('muscleData', JSON.stringify(newData));
                              }, 0);
                            }}
                            className="flex-1 bg-gray-700 border border-gray-600 text-white rounded px-3 py-2 text-sm"
                          >
                            {ABS_DIFFICULTY_LEVELS.map((level, index) => (
                              <option key={index} value={index}>
                                {level}
                              </option>
                            ))}
                          </select>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <Input
                            id={`muscle-${subMuscle}`}
                            type="number"
                            value={inputValues[subMuscle]}
                            onChange={(e) => handleWeightChange(subMuscle, e.target.value)}
                            onBlur={() => handleBlur(subMuscle)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                handleSave(subMuscle);
                                e.currentTarget.blur();
                              }
                            }}
                            className="w-24 bg-gray-700 border-gray-600 text-white"
                            min="0"
                            step="5"
                          />
                          <span className="text-sm text-gray-400">lbs</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}

        {/* Leaderboard - Remaining Positions */}
        <div className="space-y-1.5">
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Leaderboard</h3>
          {restOfGroups.map((rankedGroup, index) => {
            const position = index + 4; // Starts at position 4
            const isExpanded = expandedGroups[rankedGroup.name];
            
            return (
              <div key={rankedGroup.name}>
                <button
                  onClick={() => toggleGroup(rankedGroup.name)}
                  className="w-full flex items-center gap-2 p-2.5 bg-gray-800/50 border border-gray-700 rounded-lg hover:bg-gray-700/50 transition-all"
                >
                  {/* Position Number */}
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-700 border border-gray-600">
                    <span className="text-sm font-bold text-orange-400">#{position}</span>
                  </div>

                  {/* Muscle Name & Info */}
                  <div className="flex-1 text-left">
                    <div className="text-sm font-semibold text-gray-200">{rankedGroup.name}</div>
                    <div className="text-[10px] text-gray-400">
                      {rankedGroup.group.useDifficulty 
                        ? ABS_DIFFICULTY_LEVELS[Math.floor(rankedGroup.avgValue)]
                        : `${Math.round(rankedGroup.avgValue)} lbs`
                      }
                    </div>
                  </div>

                  {/* Rank Badge */}
                  <Badge 
                    style={{ 
                      backgroundColor: RANK_COLORS[rankedGroup.rankIndex].bgColor,
                      color: RANK_COLORS[rankedGroup.rankIndex].color,
                      borderColor: RANK_COLORS[rankedGroup.rankIndex].color
                    }}
                    className="border text-[10px] px-1.5 py-0.5"
                  >
                    {RANK_NAMES[rankedGroup.rankIndex]}
                  </Badge>

                  {/* Expand Icon */}
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-orange-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-gray-400" />
                  )}
                </button>

                {/* Expanded Sub-muscles */}
                {isExpanded && (
                  <div className="mt-1.5 ml-10 mr-2 p-3 bg-gray-900/70 border border-gray-700 rounded-lg">
                    <div className="space-y-2">
                      {rankedGroup.group.subMuscles.map(subMuscle => {
                        const value = muscleData[subMuscle] || 0;
                        const isAbs = usesDifficultyLevel(subMuscle);
                        const rank = isAbs 
                          ? getRankForDifficulty(value) 
                          : getRankForWeight(value, subMuscle);
                        
                        return (
                          <div key={subMuscle} className="flex flex-col gap-1.5 p-2 rounded-md border border-gray-600 bg-gray-800/70">
                            <div className="flex items-center justify-between">
                              <Label htmlFor={`muscle-${subMuscle}`} className="text-sm text-gray-200">
                                {subMuscle}
                              </Label>
                              <Badge 
                                style={{ 
                                  backgroundColor: rank.bgColor,
                                  color: rank.color,
                                  borderColor: rank.color
                                }}
                                className="border text-[10px] px-1.5 py-0.5"
                              >
                                {rank.name}
                              </Badge>
                            </div>
                            
                            {isAbs ? (
                              <div className="flex items-center gap-2">
                                <select
                                  id={`muscle-${subMuscle}`}
                                  value={value}
                                  onChange={(e) => {
                                    const difficultyIndex = parseInt(e.target.value);
                                    setMuscleData(prev => ({
                                      ...prev,
                                      [subMuscle]: difficultyIndex
                                    }));
                                    // Auto-save for difficulty changes
                                    setTimeout(() => {
                                      const newData = { ...muscleData, [subMuscle]: difficultyIndex };
                                      localStorage.setItem('muscleData', JSON.stringify(newData));
                                    }, 0);
                                  }}
                                  className="flex-1 bg-gray-700 border border-gray-600 text-white rounded px-2 py-1.5 text-xs"
                                >
                                  {ABS_DIFFICULTY_LEVELS.map((level, index) => (
                                    <option key={index} value={index}>
                                      {level}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2">
                                <Input
                                  id={`muscle-${subMuscle}`}
                                  type="number"
                                  value={inputValues[subMuscle]}
                                  onChange={(e) => handleWeightChange(subMuscle, e.target.value)}
                                  onBlur={() => handleBlur(subMuscle)}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      handleSave(subMuscle);
                                      e.currentTarget.blur();
                                    }
                                  }}
                                  className="w-20 bg-gray-700 border-gray-600 text-white text-sm py-1"
                                  min="0"
                                  step="5"
                                />
                                <span className="text-xs text-gray-400">lbs</span>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}