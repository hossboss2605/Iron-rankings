import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Scale, Plus, Trash2, TrendingDown, TrendingUp, Target } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface WeightEntry {
  date: string;
  weight: number;
  id: string;
}

export function WeightTracker() {
  const [entries, setEntries] = useState<WeightEntry[]>(() => {
    const saved = localStorage.getItem('weightEntries');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [newWeight, setNewWeight] = useState('');
  const [goalWeight, setGoalWeight] = useState(() => {
    const saved = localStorage.getItem('goalWeight');
    return saved ? parseFloat(saved) : 0;
  });

  useEffect(() => {
    localStorage.setItem('weightEntries', JSON.stringify(entries));
  }, [entries]);

  useEffect(() => {
    localStorage.setItem('goalWeight', goalWeight.toString());
  }, [goalWeight]);

  const addEntry = () => {
    if (!newWeight || parseFloat(newWeight) <= 0) return;
    
    const entry: WeightEntry = {
      date: new Date().toLocaleDateString(),
      weight: parseFloat(newWeight),
      id: Date.now().toString()
    };
    
    setEntries(prev => [...prev, entry]);
    setNewWeight('');
  };

  const deleteEntry = (id: string) => {
    setEntries(prev => prev.filter(e => e.id !== id));
  };

  const chartData = entries.map(entry => ({
    date: entry.date,
    weight: entry.weight
  }));

  const currentWeight = entries.length > 0 ? entries[entries.length - 1].weight : 0;
  const startWeight = entries.length > 0 ? entries[0].weight : 0;
  const weightChange = currentWeight - startWeight;
  const goalDifference = goalWeight > 0 ? goalWeight - currentWeight : 0;
  const goalProgress = goalWeight > 0 && startWeight > 0 
    ? ((startWeight - currentWeight) / (startWeight - goalWeight)) * 100 
    : 0;

  return (
    <Card className="bg-gray-900 border-orange-900 text-white">
      <CardHeader className="border-b border-orange-900">
        <CardTitle className="flex items-center gap-2 text-orange-400">
          <Scale className="w-5 h-5" />
          Weight Tracker
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Goal Weight */}
        <div>
          <Label htmlFor="goal-weight" className="text-gray-200">Goal Weight (lbs)</Label>
          <Input
            id="goal-weight"
            type="number"
            value={goalWeight || ''}
            onChange={(e) => setGoalWeight(parseFloat(e.target.value) || 0)}
            placeholder="Set your goal"
            step="0.1"
            className="w-32 bg-gray-700 border-gray-600 text-white"
          />
        </div>

        {/* Add New Weight */}
        <div className="flex gap-2">
          <div className="flex-1">
            <Label htmlFor="new-weight" className="text-gray-200">Current Weight (lbs)</Label>
            <Input
              id="new-weight"
              type="number"
              value={newWeight}
              onChange={(e) => setNewWeight(e.target.value)}
              placeholder="Enter weight"
              step="0.1"
              className="bg-gray-700 border-gray-600 text-white"
            />
          </div>
          <Button onClick={addEntry} className="mt-auto bg-orange-600 hover:bg-orange-700">
            <Plus className="w-4 h-4 mr-1" />
            Add
          </Button>
        </div>

        {/* Stats */}
        {entries.length > 0 && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="p-3 bg-gray-800 border border-gray-700 rounded-lg">
                <div className="text-sm text-gray-400">Current</div>
                <div className="font-semibold text-white">{currentWeight} lbs</div>
              </div>
              <div className="p-3 bg-gray-800 border border-gray-700 rounded-lg">
                <div className="text-sm text-gray-400">Start</div>
                <div className="font-semibold text-white">{startWeight} lbs</div>
              </div>
              <div className="p-3 bg-gray-800 border border-gray-700 rounded-lg">
                <div className="text-sm text-gray-400">Change</div>
                <div className={`font-semibold ${weightChange > 0 ? 'text-blue-400' : 'text-green-400'}`}>
                  {weightChange > 0 ? '+' : ''}{weightChange.toFixed(1)} lbs
                </div>
              </div>
            </div>

            {/* Goal Progress */}
            {goalWeight > 0 && (
              <div className="p-4 bg-gradient-to-r from-orange-900/30 to-orange-800/30 border border-orange-700 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-medium text-gray-200">Goal Progress</span>
                  <span className={`font-bold ${Math.abs(goalDifference) < 5 ? 'text-green-400' : 'text-orange-400'}`}>
                    {goalDifference > 0 ? `${goalDifference.toFixed(1)} lbs to go` : 'Goal Reached! 🎉'}
                  </span>
                </div>
                <div className="h-3 bg-gray-700 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-orange-500 to-orange-600 transition-all"
                    style={{ width: `${Math.min(Math.max(goalProgress, 0), 100)}%` }}
                  />
                </div>
                <div className="mt-2 text-sm text-gray-300 text-center">
                  {goalProgress > 0 ? `${goalProgress.toFixed(0)}% complete` : 'Start tracking to see progress'}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Chart */}
        {chartData.length > 0 && (
          <div className="h-64 bg-gray-800 p-4 rounded-lg border border-gray-700">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                <XAxis dataKey="date" stroke="#999" />
                <YAxis stroke="#999" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', color: '#fff' }}
                />
                <Line type="monotone" dataKey="weight" stroke="#f97316" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Entry List */}
        {entries.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-medium text-gray-200">History</h4>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {entries.slice().reverse().map(entry => (
                <div key={entry.id} className="flex items-center justify-between p-2 bg-gray-800 border border-gray-700 rounded">
                  <div>
                    <span className="font-medium text-white">{entry.weight} lbs</span>
                    <span className="text-sm text-gray-400 ml-2">{entry.date}</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteEntry(entry.id)}
                    className="hover:bg-gray-700"
                  >
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}