export const RANK_NAMES = [
  'Bronze',
  'Silver',
  'Gold',
  'Platinum',
  'Diamond',
  'Master',
  'Grandmaster',
  'Absolute Legend'
];

export const RANK_COLORS = [
  { color: '#CD7F32', bgColor: '#FFF8F0' },  // Bronze
  { color: '#C0C0C0', bgColor: '#F5F5F5' },  // Silver
  { color: '#FFD700', bgColor: '#FFFACD' },  // Gold
  { color: '#E5E4E2', bgColor: '#F0F0F0' },  // Platinum
  { color: '#B9F2FF', bgColor: '#E0F7FF' },  // Diamond
  { color: '#9B59B6', bgColor: '#F4ECF7' },  // Master
  { color: '#E74C3C', bgColor: '#FADBD8' },  // Grandmaster
  { color: '#FF0000', bgColor: '#FFE6E6' }   // Absolute Legend
];

// Muscle group structure with sub-muscles
export interface MuscleGroup {
  name: string;
  subMuscles: string[];
  range: { min: number; max: number };
  useDifficulty?: boolean; // For abs - use difficulty levels instead of weight
}

export const MUSCLE_GROUPS: MuscleGroup[] = [
  {
    name: 'Chest',
    subMuscles: ['Upper Chest', 'Mid Chest', 'Lower Chest'],
    range: { min: 65, max: 315 }
  },
  {
    name: 'Back',
    subMuscles: ['Upper Back', 'Mid Back', 'Lower Back'],
    range: { min: 95, max: 405 }
  },
  {
    name: 'Shoulders',
    subMuscles: ['Front Delts', 'Side Delts', 'Rear Delts'],
    range: { min: 45, max: 225 }
  },
  {
    name: 'Biceps',
    subMuscles: ['Long Head', 'Short Head'],
    range: { min: 20, max: 80 }
  },
  {
    name: 'Triceps',
    subMuscles: ['Long Head', 'Lateral Head', 'Medial Head'],
    range: { min: 30, max: 90 }
  },
  {
    name: 'Forearms',
    subMuscles: ['Flexors', 'Extensors'],
    range: { min: 20, max: 100 }
  },
  {
    name: 'Quadriceps',
    subMuscles: ['Rectus Femoris', 'Vastus Lateralis', 'Vastus Medialis', 'Vastus Intermedius'],
    range: { min: 135, max: 315 }
  },
  {
    name: 'Hamstrings',
    subMuscles: ['Biceps Femoris', 'Semitendinosus', 'Semimembranosus'],
    range: { min: 95, max: 225 }
  },
  {
    name: 'Calves',
    subMuscles: ['Gastrocnemius', 'Soleus'],
    range: { min: 100, max: 200 }
  },
  {
    name: 'Abs',
    subMuscles: ['Upper Abs', 'Lower Abs', 'Obliques'],
    range: { min: 60, max: 150 },
    useDifficulty: true
  },
  {
    name: 'Glutes',
    subMuscles: ['Gluteus Maximus', 'Gluteus Medius', 'Gluteus Minimus'],
    range: { min: 135, max: 315 }
  },
  {
    name: 'Traps',
    subMuscles: ['Upper Traps', 'Mid Traps', 'Lower Traps'],
    range: { min: 95, max: 225 }
  }
];

// Flatten all sub-muscles for storage
export const ALL_SUB_MUSCLES: string[] = MUSCLE_GROUPS.flatMap(group => 
  group.subMuscles
);

// Map sub-muscle to parent group
export const SUB_MUSCLE_TO_GROUP: { [key: string]: string } = {};
MUSCLE_GROUPS.forEach(group => {
  group.subMuscles.forEach(subMuscle => {
    SUB_MUSCLE_TO_GROUP[subMuscle] = group.name;
  });
});

// Default beginner weights for each sub-muscle (set to min values)
export const DEFAULT_WEIGHTS: { [key: string]: number } = {};
MUSCLE_GROUPS.forEach(group => {
  group.subMuscles.forEach(subMuscle => {
    // For abs, start at difficulty level 0 (Beginner), for others use min weight
    DEFAULT_WEIGHTS[subMuscle] = group.useDifficulty ? 0 : group.range.min;
  });
});

// Get range for a sub-muscle by finding its parent group
export function getRangeForSubMuscle(subMuscle: string): { min: number; max: number } {
  const parentGroup = SUB_MUSCLE_TO_GROUP[subMuscle];
  const group = MUSCLE_GROUPS.find(g => g.name === parentGroup);
  return group ? group.range : { min: 50, max: 300 };
}

// Generate ranks dynamically for a sub-muscle
function generateRanksForMuscle(subMuscle: string) {
  const range = getRangeForSubMuscle(subMuscle);
  if (!range) return [];

  const totalRange = range.max - range.min;
  const tierSize = totalRange / 8;
  const ranks = [];

  for (let i = 0; i < 8; i++) {
    const min = range.min + (tierSize * i);
    const max = i === 7 ? Infinity : range.min + (tierSize * (i + 1));
    
    ranks.push({
      name: RANK_NAMES[i],
      min: Math.round(min * 100) / 100,
      max: Math.round(max * 100) / 100,
      color: RANK_COLORS[i].color,
      bgColor: RANK_COLORS[i].bgColor
    });
  }

  return ranks;
}

export function getRankForWeight(weight: number, muscle?: string) {
  if (!muscle) {
    // Fallback to default ranks if no muscle specified
    const defaultRanks = generateRanksForMuscle('Upper Chest');
    return defaultRanks.find(rank => weight >= rank.min && weight <= rank.max) || defaultRanks[0];
  }

  const ranks = generateRanksForMuscle(muscle);
  return ranks.find(rank => weight >= rank.min && weight <= rank.max) || ranks[0];
}

export function getRankColor(weight: number, muscle?: string): string {
  const rank = getRankForWeight(weight, muscle);
  // Brighter, more vibrant colors for muscle map
  const brightColors: { [key: string]: string } = {
    '#CD7F32': '#8B5A2B', // Bronze -> darker bronze
    '#C0C0C0': '#808080', // Silver -> medium gray
    '#FFD700': '#B8860B', // Gold -> dark goldenrod
    '#E5E4E2': '#A9A9A9', // Platinum -> dark gray
    '#B9F2FF': '#4682B4', // Diamond -> steel blue
    '#9B59B6': '#8B008B', // Master -> dark magenta
    '#E74C3C': '#DC143C', // Grandmaster -> crimson
    '#FF0000': '#B22222'  // Absolute Legend -> firebrick red
  };
  return brightColors[rank.color] || rank.color;
}

// Get average weight for a muscle group from its sub-muscles
export function getAverageWeightForGroup(groupName: string, muscleData: { [key: string]: number }): number {
  const group = MUSCLE_GROUPS.find(g => g.name === groupName);
  if (!group) return 50;

  const weights = group.subMuscles.map(subMuscle => muscleData[subMuscle] || group.range.min);
  const sum = weights.reduce((acc, w) => acc + w, 0);
  return sum / weights.length;
}

// Get rank color for muscle group visualization (handles both weight and difficulty)
export function getRankColorForGroup(groupName: string, muscleData: { [key: string]: number }): string {
  const group = MUSCLE_GROUPS.find(g => g.name === groupName);
  if (!group) return '#1a1a1a';

  if (group.useDifficulty) {
    // For abs: average the difficulty indices (0-7) and get rank color
    const difficultyValues = group.subMuscles.map(subMuscle => muscleData[subMuscle] || 0);
    const avgDifficulty = difficultyValues.reduce((acc, val) => acc + val, 0) / difficultyValues.length;
    const rankIndex = Math.min(Math.floor(avgDifficulty), 7);
    const color = RANK_COLORS[rankIndex].color;
    
    // Brighter, more vibrant colors for muscle map
    const brightColors: { [key: string]: string } = {
      '#CD7F32': '#8B5A2B', // Bronze -> darker bronze
      '#C0C0C0': '#808080', // Silver -> medium gray
      '#FFD700': '#B8860B', // Gold -> dark goldenrod
      '#E5E4E2': '#A9A9A9', // Platinum -> dark gray
      '#B9F2FF': '#4682B4', // Diamond -> steel blue
      '#9B59B6': '#8B008B', // Master -> dark magenta
      '#E74C3C': '#DC143C', // Grandmaster -> crimson
      '#FF0000': '#B22222'  // Absolute Legend -> firebrick red
    };
    return brightColors[color] || color;
  } else {
    // For weight-based muscles: use existing logic
    const avgWeight = getAverageWeightForGroup(groupName, muscleData);
    return getRankColor(avgWeight, groupName);
  }
}

// Difficulty levels for abs (maps to rank tiers)
export const ABS_DIFFICULTY_LEVELS = [
  'Beginner',      // Bronze
  'Intermediate',  // Silver
  'Advanced',      // Gold
  'Expert',        // Platinum
  'Elite',         // Diamond
  'Master',        // Master
  'Grandmaster',   // Grandmaster
  'Extreme'        // Absolute Legend
];

// Check if a muscle uses difficulty levels instead of weight
export function usesDifficultyLevel(muscle: string): boolean {
  const parentGroup = SUB_MUSCLE_TO_GROUP[muscle];
  const group = MUSCLE_GROUPS.find(g => g.name === parentGroup);
  return group?.useDifficulty || false;
}

// Get rank for difficulty level (for abs)
export function getRankForDifficulty(difficultyIndex: number) {
  const index = Math.min(Math.max(difficultyIndex, 0), 7);
  return {
    name: RANK_NAMES[index],
    difficulty: ABS_DIFFICULTY_LEVELS[index],
    color: RANK_COLORS[index].color,
    bgColor: RANK_COLORS[index].bgColor
  };
}